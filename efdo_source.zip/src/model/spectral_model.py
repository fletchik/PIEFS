from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from .basis.basis_set import BasisSet


class BinaryHead(nn.Module):
    """Classification head for binary tasks: Linear(K→1) + BCEWithLogitsLoss.

    Args:
        K: Number of basis functions (input dimensionality).
    """

    def __init__(self, K: int) -> None:
        super().__init__()
        self.linear = nn.Linear(K, 1)

    def forward(self, phi: torch.Tensor, y: torch.Tensor) -> dict[str, torch.Tensor]:
        """
        Args:
            phi: (B, K) basis function outputs.
            y: (B,) binary labels in {0, 1}.
        Returns:
            dict with keys: loss (scalar), logits (B,), probs (B,).
        """
        logits = self.linear(phi).squeeze(-1)  # (B,)
        loss = F.binary_cross_entropy_with_logits(logits, y.float())
        return {'loss': loss, 'logits': logits, 'probs': torch.sigmoid(logits)}


class MulticlassHead(nn.Module):
    """Classification head for multiclass tasks: Linear(K→C) + CrossEntropyLoss.

    Args:
        K: Number of basis functions (input dimensionality).
        num_classes: Number of target classes C.
    """

    def __init__(self, K: int, num_classes: int) -> None:
        super().__init__()
        self.linear = nn.Linear(K, num_classes)
        self.num_classes = num_classes

    def forward(self, phi: torch.Tensor, y: torch.Tensor) -> dict[str, torch.Tensor]:
        """
        Args:
            phi: (B, K) basis function outputs.
            y: (B,) integer class labels in [0, C).
        Returns:
            dict with keys: loss (scalar), logits (B, C), probs (B, C).
        """
        logits = self.linear(phi)  # (B, C)
        loss = F.cross_entropy(logits, y.long())
        return {'loss': loss, 'logits': logits, 'probs': F.softmax(logits, dim=-1)}


class SpectralModel(nn.Module):
    """Spectral Dirichlet model combining basis set, Riemannian metric, and task head.

    During sequential training the trainer calls basis_set.set_active(k) to
    unfreeze φ_k. This model's forward assembles Φ_{1..k} and routes the
    representation to the head.

    Args:
        basis_set: Manages K scalar eigenfunctions.
        metric: Riemannian metric module (None for OFF variant).
        head: BinaryHead or MulticlassHead, injected at construction.
    """

    def __init__(
        self,
        basis_set: BasisSet,
        metric: nn.Module | None,
        head: nn.Module,
    ) -> None:
        super().__init__()
        self.basis_set = basis_set
        self.metric = metric
        self.head = head
        self.K = basis_set.K
        self._active_k: int = 0

    def set_active_k(self, k: int) -> None:
        """Tell the model which function is currently being trained (1-indexed)."""
        self._active_k = k

    def forward(
        self,
        x: torch.Tensor,
        y: torch.Tensor,
    ) -> dict[str, torch.Tensor]:
        """Run the full forward pass for the current active function k.

        Args:
            x: (B, d) input features.
            y: (B,) labels.
        Returns:
            phi_matrix: (B, k) — first k-1 columns detached, k-th has gradient.
            grad_phi_k: (B, d) gradient of the active function w.r.t. x.
            A: (B, d, d) metric, or None for OFF.
            head_out: dict from head forward (loss, logits, probs).
        """
        k = self._active_k
        phi_matrix, grad_phi_k = self.basis_set.get_phi_matrix(x, k)  # (B, k), (B, d)

        # Zero-pad phi to (B, K) for the head so its linear layer has fixed shape.
        B = x.shape[0]
        phi_full = phi_matrix.new_zeros(B, self.K)
        phi_full[:, :k] = phi_matrix

        # Compute metric. Four cases passed to the loss:
        #   A=None,  Ag=None  → identity ('off'):       loss = ||∇φ||²
        #   A=(B,d), Ag=None  → diagonal (DiagMetric):  loss = ||λ⊙∇φ||²
        #   A=(B,d,d),Ag=None → full matrix (Sparse):   loss = ||A∇φ||²
        #   A=None,  Ag=(B,d) → PINN pre-applied:       loss = ||Ag||²
        #                        Ag = U(x)·Λ(x)·∇φ already computed via one PINN call.
        A, Ag_pinn = None, None
        if self.metric is None:
            pass  # identity
        elif hasattr(self.metric, 'apply_to') and grad_phi_k is not None:
            # Metrics with apply_to (LambdaUPinn, LambdaUTrotter): compute Ag = A(x)·∇φ
            # directly in O(B·d) — avoids building the full (B, d, d) matrix which
            # would cost O(B·d²) and is only needed for visualisation.
            Ag_pinn = self.metric.apply_to(x, grad_phi_k)  # (B, d)
        else:
            A = self.metric(x)  # (B, d) diag or (B, d, d) full

        head_out = self.head(phi_full, y)

        return {
            'phi_matrix': phi_matrix,
            'grad_phi_k': grad_phi_k,
            'A': A,
            'Ag_pinn': Ag_pinn,   # pre-applied result, use directly as ||Ag||²
            'head_out': head_out,
        }
